﻿<html lang="ko">
<head>

<script type="text/javascript">
    function checkInput(form) {               
        var robj = document.getElementsByName("answer");
        var chk = false;
        for(i=0;i<robj.length;i++){
            if(robj[i].checked == true){
                chk = true; break;
            } 
        } 
        if(!chk) {
            alert("가장 근접한 응답으로 체크해주세요.");
            return false;
        }        
        return true;
    }
</script>


<meta charset="UTF-8" />
<title>BebeCODE 아동발달검사지</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0" />
<meta name="format-detection" content="telephone=no" />
<meta name="mobile-web-app-capable" content="yes">
</head>
<body>
<?
	$q_n = $_REQUEST['q_n'];
	$question_type = "알수 없음";
	
	$question_1 = substr($q_n,6, 1) - 1;
	$question_2 = substr($q_n,8, 1) - 1;

	$target_line = ($question_1 * 8) + $question_2;	
	$filepath = "question/".$_REQUEST['q_f'];
	
	$fp = fopen($filepath,"r"); 
	
	$count = 0;
	while( !feof($fp) ) {		
		$target_question = fgets($fp);		
		if($target_line == $count){			
			break;
		}			
		$count = $count + 1;
	}
	fclose($fp); 
	
	switch(substr($q_n,6, 1)){
		case 1: $question_type = "대근육운동"; break;
		case 2: $question_type = "소근육운동"; break;
		case 3: $question_type = "인지"; break;
		case 4: $question_type = "언어";break;
		case 5:$question_type = "사회성";break;
		case 6:$question_type = "자조";break;
	}
?>


<center>
<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;border-color:#aabcfe;border:none;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#aabcfe;color:#669;background-color:#e8edff;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#aabcfe;color:#039;background-color:#b9c9fe;}
.tg .tg-e3zv{font-weight:bold}
</style>
<form action=done.php method=post onSubmit='return checkInput(this);'>
<table class="tg" align="center">
  <tr>
    <th class="tg-e3zv"><? echo $_REQUEST['q_n']; ?></th>
    <th class="tg-031e"><? echo $question_type; ?></th>
    <th class="tg-031e" colspan="3"> 아동 : <? echo $_REQUEST['name']; ?></th>
  </tr>
  <tr>
    <td class="tg-031e" colspan="4"><? echo $target_question; ?></td>
  </tr>
  <tr>        
    <td class="tg-031e" colspan="2" align="center" >못하는 편</td>
    <td class="tg-031e" colspan="2" align="center" >할 수 있는 편&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>    
  </tr>
  <tr>        
    <td class="tg-031e" align="center" colspan="2"><input type="radio" name="answer" value="못하는 편"/></td>
    <td class="tg-031e" align="center" colspan="2"><input type="radio" name="answer" value="할 수 있는 편"/></td>    
  </tr>
</table>
<br>
<input type="hidden" value="<? echo $_REQUEST['name'];?>" name="username">
<input type="hidden" value="<? echo $_REQUEST['id'];?>" name="userid">
<input type="hidden" value="<? echo $_REQUEST['q_n'];?>" name="q_n">
<input type="hidden" value="<? echo $target_question;?>" name="qqqqq">
<input type="hidden" value="<? echo $question_type;?>" name="type">

<input type="submit" VALUE="등록하기">&nbsp&nbsp&nbsp&nbsp
 <input type ="reset" VALUE="취소하기">
</center>
</form>







