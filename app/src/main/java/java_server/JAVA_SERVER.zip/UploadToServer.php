<?php
  
    $file_path = "uploads/";     
    $file_path = $file_path . basename($_FILES['uploaded_file']['name']);
	
	        
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $file_path)) {				
        echo "success";
    } else{
        echo "fail";
    }
	
	$ini = strpos(basename( $_FILES['uploaded_file']['name']) , "_");    
	$childid = substr( basename( $_FILES['uploaded_file']['name']) , 0 , $ini  );	
	
	$video = "mp4";	
	
	if ( ereg($video, basename($_FILES['uploaded_file']['name']))  ){
		copy($file_path, "uploads/" . $childid . "_last_upload_movie");
	}else {
		copy($file_path, "uploads/" . $childid . "_last_upload");
	}

 ?>