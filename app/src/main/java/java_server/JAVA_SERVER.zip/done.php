﻿
<html lang="ko">
<head>
<meta charset="UTF-8" />
<title>BebeCODE 아동발달검사지</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0" />
<meta name="format-detection" content="telephone=no" />
<meta name="mobile-web-app-capable" content="yes">
</head>
<body>
<center>

<?php
$username = $_REQUEST['username'];
$userid = $_REQUEST['userid'];
$q_n = $_REQUEST['q_n'];	
$answer = $_REQUEST['answer'];
$type = $_REQUEST['type'];

$filepath = "BabyDevelopmentServer/".$userid."/".$userid."_teacher.txt";

	
$question_1 = substr($q_n,6, 1) - 1;
$question_2 = substr($q_n,8, 1) - 1;

$position = ($question_1 * 8 ) + $question_2;

	$fp = fopen($filepath,"r"); 
	
	
	
	// Write File
	
	$count = 0;
	while( $fp &&  !feof($fp) ) {		
		$line = fgets($fp);		
				
		if($count == $question_1){	
			$line_array = explode(' ', $line );
					
				if(strcmp($_REQUEST['answer'],"못하는 편")==0){
					$line_array[$question_2] = 1;
				}
				else
					$line_array[$question_2] = 2;	
			for($i=0 ; $i<count($line_array) ; $i++){				
				if ($i==count($line_array)-1)
					$line_new .=$line_array[$i];
				else								
					$line_new .=$line_array[$i]." ";
			}			
			
			$buffer .= $line_new;
		}
		else			
			$buffer .=$line;
		
		$count = $count + 1;
	}
	fclose($fp); 

	$fw = fopen($filepath, "w");
	fwrite ($fw , $buffer);
	fclose($fw);

	
	
	// Send push data to my server
	
		$address = "143.248.134.177";
		$port = 33333;

		$socket = socket_create(AF_INET, SOCK_STREAM, 0);
		if($socket < 0)
			echo "socket() failed - ".sterror($socket)."<br>";

		$result = socket_connect($socket, $address, $port);
		if($result < 0)
			echo "connect() failed - ".sterror($result)."<br>";
	
		socket_write($socket, "%%NOTHING%%##SET_TEACHER_DATA##".$userid."##".$q_n."##".$answer."##".$type."##");
		socket_close($socket);
				
		// send teacher timer data to my server		
		$socket = socket_create(AF_INET, SOCK_STREAM, 0);
		if($socket < 0)
			echo "socket() failed - ".sterror($socket)."<br>";

		$result = socket_connect($socket, $address, $port);
		if($result < 0)
			echo "connect() failed - ".sterror($result)."<br>";
			
		socket_write($socket, "%%TEACHER%%##SET_TIMER##".$userid."##".$position."##168##");
		socket_close($socket);
	
?>

<br>

[응답내용]<br><br>

<font color="blue"> <? echo $_REQUEST['qqqqq']; ?> </font><br><br>
의견으로 <font color="red"> <? echo $_REQUEST['answer']; ?> </font> 으로 기록하였습니다. <br><br>

응답해 주셔서 감사합니다. <br>

</center>



</body>

</html>